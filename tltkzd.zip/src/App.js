import "./styles.css";
import Chakra from "./components/ChakraUi"
export default function App() {
  return (
    <div className="App">

    <Chakra />
    </div>
  );
}
